import { QueryClientProvider } from "@tanstack/react-query";
import { Stack } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import React, { useEffect, useRef } from "react";
import { AppState, AppStateStatus, Platform, View, ActivityIndicator } from "react-native";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { KeyboardProvider } from "react-native-keyboard-controller";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { queryClient } from "@/lib/query-client";
import { AuthProvider, useAuth } from "@/context/AuthContext";
import { useFonts, Inter_400Regular, Inter_500Medium, Inter_600SemiBold, Inter_700Bold } from "@expo-google-fonts/inter";
import { Colors } from "@/constants/colors";
import NotifPermissionBanner from "@/components/NotifPermissionBanner";
import { scheduleMaintenanceNotifications } from "@/lib/notificationScheduler";
import { BudgetAlertProvider } from "@/context/BudgetAlertContext";
import * as Notifications from "expo-notifications";
import * as Linking from "expo-linking";
import { supabase } from "@/lib/supabase";

SplashScreen.preventAutoHideAsync();

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

const VOICE_LOG_URL = "lifemaintained://voice-log";

function RootLayoutNav() {
  const { session, isLoading, onboardingCompleted, refreshProfile } = useAuth();
  const appStateRef = useRef<AppStateStatus>(AppState.currentState);
  const rcListenerRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    if (!isLoading) {
      SplashScreen.hideAsync();
    }
  }, [isLoading]);

  useEffect(() => {
    if (!session?.user?.id || !onboardingCompleted) return;
    const userId = session.user.id;

    Notifications.setBadgeCountAsync(0).catch(() => {});
    scheduleMaintenanceNotifications(userId);

    const sub = AppState.addEventListener("change", (nextState: AppStateStatus) => {
      const prev = appStateRef.current;
      appStateRef.current = nextState;
      if (nextState === "active" && prev !== "active") {
        Notifications.setBadgeCountAsync(0).catch(() => {});
        scheduleMaintenanceNotifications(userId);
      }
    });

    return () => sub.remove();
  }, [session?.user?.id, onboardingCompleted]);

  useEffect(() => {
    if (!session?.user?.id || Platform.OS === "web") return;
    const userId = session.user.id;

    (async () => {
      try {
        const Purchases = (await import("react-native-purchases")).default;
        await Purchases.logIn(userId);

        if (rcListenerRef.current) {
          rcListenerRef.current();
          rcListenerRef.current = null;
        }

        const listener = async (info: any) => {
          try {
            const active = info?.entitlements?.active ?? {};
            const expiry = (key: string) =>
              active[key]?.expirationDate ?? null;

            let newTier: string | null = null;
            let newExpiry: string | null = null;

            if (active["business_access"] != null) {
              newTier = "business";
              newExpiry = expiry("business_access");
            } else if (active["pro_access"] != null) {
              newTier = "pro";
              newExpiry = expiry("pro_access");
            } else if (active["personal_access"] != null) {
              newTier = "personal";
              newExpiry = expiry("personal_access");
            }

            if (newTier) {
              await supabase.from("profiles").update({
                subscription_tier: newTier,
                subscription_expires_at: newExpiry,
                revenuecat_customer_id: info.originalAppUserId ?? null,
              }).eq("user_id", userId);
            } else {
              const { data: prof } = await supabase
                .from("profiles")
                .select("trial_expires_at")
                .eq("user_id", userId)
                .single();
              const stillTrial =
                prof &&
                (prof as any).trial_expires_at &&
                new Date((prof as any).trial_expires_at) > new Date();
              if (!stillTrial) {
                await supabase.from("profiles").update({
                  subscription_tier: "free",
                }).eq("user_id", userId);
              }
            }
            refreshProfile().catch(() => {});
          } catch {}
        };

        Purchases.addCustomerInfoUpdateListener(listener);
        rcListenerRef.current = () => Purchases.removeCustomerInfoUpdateListener(listener);
      } catch {}
    })();

    return () => {
      if (rcListenerRef.current) {
        rcListenerRef.current();
        rcListenerRef.current = null;
      }
    };
  }, [session?.user?.id]);

  // Deep link: lifemaintained://voice-log → navigate to dashboard tab
  useEffect(() => {
    if (!session || isLoading) return;
    const { router } = require("expo-router");

    const handleUrl = (url: string | null) => {
      if (!url) return;
      try {
        const parsed = Linking.parse(url);
        if (parsed.scheme === "lifemaintained" && parsed.path === "voice-log") {
          router.navigate("/(tabs)");
        }
      } catch {}
    };

    Linking.getInitialURL().then(handleUrl);
    const sub = Linking.addEventListener("url", (e) => handleUrl(e.url));
    return () => sub.remove();
  }, [session, isLoading]);

  if (isLoading) {
    return (
      <View style={{ flex: 1, backgroundColor: Colors.background, justifyContent: "center", alignItems: "center" }}>
        <ActivityIndicator color={Colors.accent} />
      </View>
    );
  }

  const showBanner = !!session && onboardingCompleted === true;

  return (
    <BudgetAlertProvider userId={session?.user?.id ?? null}>
      <View style={{ flex: 1 }}>
        <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: Colors.background } }}>
          <Stack.Screen name="(auth)" options={{ headerShown: false }} />
          <Stack.Screen name="(onboarding)" options={{ headerShown: false, presentation: "modal" }} />
          <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
          <Stack.Screen name="add-vehicle" options={{ headerShown: false, presentation: "modal" }} />
          <Stack.Screen name="vehicle/[id]" options={{ headerShown: false }} />
          <Stack.Screen name="log-service/[vehicleId]" options={{ headerShown: false, presentation: "modal" }} />
          <Stack.Screen name="add-property" options={{ headerShown: false, presentation: "modal" }} />
          <Stack.Screen name="property/[id]" options={{ headerShown: false }} />
          <Stack.Screen name="add-property-task/[propertyId]" options={{ headerShown: false, presentation: "modal" }} />
          <Stack.Screen name="property-task-history/[propertyId]" options={{ headerShown: false }} />
          <Stack.Screen name="vehicle-task-history/[vehicleId]" options={{ headerShown: false }} />
          <Stack.Screen name="family-member/[id]" options={{ headerShown: false }} />
          <Stack.Screen name="add-appointment" options={{ headerShown: false, presentation: "modal" }} />
          <Stack.Screen name="add-medication" options={{ headerShown: false, presentation: "modal" }} />
          <Stack.Screen name="add-family-member" options={{ headerShown: false, presentation: "modal" }} />
          <Stack.Screen name="health-profile" options={{ headerShown: false, presentation: "modal" }} />
          <Stack.Screen name="update-mileage/[vehicleId]" options={{ headerShown: false, presentation: "modal" }} />
          <Stack.Screen name="subscription" options={{ headerShown: false, presentation: "modal" }} />
          <Stack.Screen name="notifications-settings" options={{ headerShown: false, presentation: "modal" }} />
          <Stack.Screen name="terms-of-service" options={{ headerShown: false, presentation: "modal" }} />
          <Stack.Screen name="privacy-policy" options={{ headerShown: false, presentation: "modal" }} />
        </Stack>
        {showBanner && <NotifPermissionBanner />}
      </View>
    </BudgetAlertProvider>
  );
}

export default function RootLayout() {
  const [fontsLoaded, fontError] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
    Inter_700Bold,
  });

  useEffect(() => {
    if (fontsLoaded || fontError) {
      SplashScreen.hideAsync();
    }
  }, [fontsLoaded, fontError]);

  useEffect(() => {
    if (Platform.OS === "web") return;
    (async () => {
      try {
        const Purchases = (await import("react-native-purchases")).default;
        const apiKey = process.env.EXPO_PUBLIC_REVENUECAT_API_KEY;
        if (apiKey && apiKey !== "YOUR_REVENUECAT_API_KEY_HERE") {
          Purchases.configure({ apiKey });
        }
      } catch {}
    })();
  }, []);

  if (!fontsLoaded && !fontError) return null;

  return (
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <GestureHandlerRootView style={{ flex: 1 }}>
          <KeyboardProvider>
            <AuthProvider>
              <RootLayoutNav />
            </AuthProvider>
          </KeyboardProvider>
        </GestureHandlerRootView>
      </QueryClientProvider>
    </ErrorBoundary>
  );
}
