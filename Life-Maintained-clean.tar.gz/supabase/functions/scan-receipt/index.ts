import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const ANTHROPIC_API_KEY = Deno.env.get("ANTHROPIC_API_KEY");

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

interface ReceiptData {
  date: string | null;
  cost: number | null;
  provider: string | null;
  serviceType: string | null;
  rawText: string;
  error?: string;
}

function detectMediaType(base64: string): string {
  // Inspect the first few bytes (base64 decoded) to identify the format
  const prefix = base64.substring(0, 16);
  const decoded = atob(prefix);
  const bytes = decoded.split("").map((c) => c.charCodeAt(0));

  // PNG: 137 80 78 71
  if (bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47) {
    return "image/png";
  }
  // JPEG: 255 216 255
  if (bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) {
    return "image/jpeg";
  }
  // GIF: 71 73 70
  if (bytes[0] === 0x47 && bytes[1] === 0x49 && bytes[2] === 0x46) {
    return "image/gif";
  }
  // WebP: RIFF....WEBP
  if (bytes[0] === 0x52 && bytes[1] === 0x49 && bytes[2] === 0x46 && bytes[3] === 0x46) {
    return "image/webp";
  }
  // Default to JPEG
  return "image/jpeg";
}

function stripDataUrlPrefix(base64: string): string {
  // Strip "data:image/...;base64," prefix if present
  const match = base64.match(/^data:[^;]+;base64,(.+)$/);
  return match ? match[1] : base64;
}

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  if (!ANTHROPIC_API_KEY) {
    console.error("ANTHROPIC_API_KEY is not set");
    return new Response(JSON.stringify({ error: "ANTHROPIC_API_KEY secret is not configured" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  let rawImage: string;
  try {
    const body = await req.json();
    rawImage = body.image;
    if (!rawImage) throw new Error("No image provided");
  } catch (err) {
    console.error("Bad request body:", err);
    return new Response(JSON.stringify({ error: "Invalid request body — expected { image: base64string }" }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  // Clean and detect
  const base64 = stripDataUrlPrefix(rawImage);
  const mediaType = detectMediaType(base64);
  console.log(`Image media type detected: ${mediaType}, base64 length: ${base64.length}`);

  const prompt = `You are analyzing a service receipt or invoice image. Extract the following fields exactly as they appear:

1. date — The service or transaction date. Format as YYYY-MM-DD. Return null if not found.
2. cost — The total amount charged as a number (no currency symbol). Use the final total/amount due. Return null if not found.
3. provider — The business or service provider name (e.g. "Jiffy Lube", "AutoNation", "Dr. Smith's Clinic"). Return null if not found.
4. serviceType — A short description of the service performed (e.g. "Oil Change", "Tire Rotation", "Brake Inspection"). Return null if not found.

Respond ONLY with a valid JSON object in this exact format, no extra text:
{
  "date": "YYYY-MM-DD or null",
  "cost": number or null,
  "provider": "string or null",
  "serviceType": "string or null",
  "rawText": "a brief summary of what you can read on the receipt"
}`;

  try {
    const requestBody = {
      model: "claude-3-5-haiku-20241022",
      max_tokens: 512,
      messages: [
        {
          role: "user",
          content: [
            {
              type: "image",
              source: {
                type: "base64",
                media_type: mediaType,
                data: base64,
              },
            },
            {
              type: "text",
              text: prompt,
            },
          ],
        },
      ],
    };

    console.log("Calling Anthropic API...");
    const anthropicRes = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "x-api-key": ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
      },
      body: JSON.stringify(requestBody),
    });

    if (!anthropicRes.ok) {
      const errText = await anthropicRes.text();
      console.error(`Anthropic API error ${anthropicRes.status}:`, errText);
      return new Response(
        JSON.stringify({
          error: `Anthropic API returned ${anthropicRes.status}: ${errText}`,
          date: null, cost: null, provider: null, serviceType: null, rawText: "",
        }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const anthropicData = await anthropicRes.json();
    console.log("Anthropic response received, stop_reason:", anthropicData.stop_reason);
    const rawContent: string = anthropicData.content?.[0]?.text ?? "";

    let parsed: ReceiptData;
    try {
      const jsonMatch = rawContent.match(/\{[\s\S]*\}/);
      if (!jsonMatch) throw new Error("No JSON found in response: " + rawContent);
      const obj = JSON.parse(jsonMatch[0]);
      parsed = {
        date: obj.date && obj.date !== "null" ? String(obj.date) : null,
        cost: obj.cost != null && obj.cost !== "null" ? Number(obj.cost) : null,
        provider: obj.provider && obj.provider !== "null" ? String(obj.provider) : null,
        serviceType: obj.serviceType && obj.serviceType !== "null" ? String(obj.serviceType) : null,
        rawText: typeof obj.rawText === "string" ? obj.rawText : rawContent.slice(0, 300),
      };
    } catch (parseErr) {
      console.error("Failed to parse Anthropic JSON response:", parseErr, "Raw:", rawContent);
      parsed = {
        date: null, cost: null, provider: null, serviceType: null,
        rawText: rawContent.slice(0, 300),
        error: "Could not parse receipt fields",
      };
    }

    return new Response(JSON.stringify(parsed), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("scan-receipt unexpected error:", err);
    return new Response(
      JSON.stringify({ error: "Internal server error", date: null, cost: null, provider: null, serviceType: null, rawText: "" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
